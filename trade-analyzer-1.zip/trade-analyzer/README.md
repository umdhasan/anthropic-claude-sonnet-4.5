# 📈 Trade Analyzer

লাইভ মার্কেট ডাটা, মাল্টি-টাইমফ্রেম সিগন্যাল, অ্যালার্ট এবং স্ক্রিনশট থেকে AI রিপোর্ট দেওয়ার ওয়েব অ্যাপ।

## কী কী আছে
- **মার্কেট:** 28টি Forex জোড়া, 20টি Crypto, Gold/Silver/Oil, প্রধান Indices ও জনপ্রিয় Stocks
- **লাইভ ক্যান্ডেল চার্ট** (EMA9/EMA21 সহ), প্রতি 15 সেকেন্ডে রিফ্রেশ
- **টাইমফ্রেম:** 1m, 5m, 15m, 30m, 1h, 4h — প্রতিটির সিগন্যাল (বাই/সেল/নিউট্রাল), শক্তি, সাপোর্ট-রেজিস্ট্যান্স, সম্ভাব্য টার্গেট ও স্টপ লস
- **ট্রেড প্ল্যান:** কোন টাইমফ্রেমের ক্যান্ডেল দেখবেন, কোনটি দিয়ে কনফার্ম করবেন, কত সময় ধরে রাখবেন
- **অ্যালার্ট:** প্রতি মিনিটে সব টাইমফ্রেম চেক হয়; সিগন্যাল বদলালে বা দ্রুত পতন/উত্থান হলে ব্রাউজার নোটিফিকেশন ও বিপ শব্দ (অ্যাপ খোলা থাকতে হবে)
- **স্ক্রিনশট বিশ্লেষণ:** যেকোনো প্ল্যাটফর্মের (Pocket Option, Quotex, MT4/MT5 ইত্যাদি) চার্টের স্ক্রিনশট দিলে Claude বাংলায় বিস্তারিত রিপোর্ট দেয়

## ডিপ্লয় করার ধাপ (Vercel — বিনামূল্যে)
1. GitHub-এ নতুন repository খুলুন (যেমন `trade-analyzer`)।
2. এই ZIP আনজিপ করে সব ফাইল repository-তে আপলোড করুন (GitHub → *Add file → Upload files*)।
3. https://vercel.com এ GitHub দিয়ে লগইন করুন → **Add New → Project** → আপনার repository সিলেক্ট করে **Deploy**।
4. স্ক্রিনশট বিশ্লেষণের জন্য: Vercel → Project → **Settings → Environment Variables** এ যোগ করুন
   `AI_GATEWAY_API_KEY` (Vercel AI Gateway key) অথবা `ANTHROPIC_API_KEY` — তারপর **Redeploy**।
5. Vercel-এর দেওয়া লিংক ফোন বা কম্পিউটারে খুলুন।

## নিজের কম্পিউটারে চালানো
```bash
npm install
cp .env.example .env.local   # এখানে ANTHROPIC_API_KEY বসান
npm run dev
```
তারপর http://localhost:3000 খুলুন।

## সীমাবদ্ধতা (সৎভাবে জেনে রাখুন)
- **100% সফলতা কোনো সিস্টেমে সম্ভব নয়।** এখানকার সিগন্যাল শুধু ইন্ডিকেটরের (EMA, RSI, MACD, Bollinger, Stochastic, ATR) সম্মিলিত ইঙ্গিত; "শক্তি %" জয়ের সম্ভাবনা নয়।
- **Pocket Option/Quotex-এর OTC প্রাইস** ওই ব্রোকারের নিজস্ব, কোনো পাবলিক API নেই। তাই সেগুলোর জন্য স্ক্রিনশট বিশ্লেষণ ব্যবহার করুন। অ্যাপের লাইভ চার্ট আসল মার্কেট ডাটা (Yahoo Finance / Binance) দেখায়, যা ব্রোকারের প্রাইসের সাথে সামান্য আলাদা হতে পারে।
- ফরেক্স/স্টক মার্কেট বন্ধ থাকলে (সপ্তাহান্ত) ডাটা আসবে না; ক্রিপ্টো 24/7 চলে।
- ব্রাউজার নোটিফিকেশন কাজ করতে অ্যাপ ট্যাব খোলা থাকতে হবে।
- এটি আর্থিক পরামর্শ নয়। আগে ডেমো অ্যাকাউন্টে পরীক্ষা করুন এবং যা হারাতে পারবেন শুধু তা-ই ঝুঁকিতে রাখুন।

## GitHub Actions (অটো বিল্ড ও ডিপ্লয়)
`.github/workflows/deploy.yml` প্রতিটি `main` push-এ বিল্ড চেক করে। অটো-ডিপ্লয় চালু করতে:
1. Vercel-এ একবার প্রজেক্ট ইমপোর্ট করুন (ধাপ 3), তারপর `npm i -g vercel && vercel link` চালিয়ে `.vercel/project.json` থেকে `orgId` ও `projectId` নিন।
2. Vercel → Account Settings → Tokens থেকে একটি token বানান।
3. GitHub repo → Settings → Secrets and variables → Actions:
   - **Secrets:** `VERCEL_TOKEN`, `VERCEL_ORG_ID`, `VERCEL_PROJECT_ID`
   - **Variables:** `DEPLOY_ENABLED` = `true`
4. API key Vercel-এর Environment Variables-এ রাখুন (কোডে বা GitHub repo ফাইলে নয়)।

> GitHub Pages এই অ্যাপ চালাতে পারে না, কারণ লাইভ ডাটার জন্য সার্ভার API দরকার। তাই Vercel ব্যবহার করা হয়েছে।
