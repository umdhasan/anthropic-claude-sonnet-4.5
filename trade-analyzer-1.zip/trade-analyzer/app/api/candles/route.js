import { NextResponse } from 'next/server';
import { findMarket } from '../../../lib/markets';

export const dynamic = 'force-dynamic';

const YAHOO = {
  '1m': { interval: '1m', range: '1d' },
  '5m': { interval: '5m', range: '5d' },
  '15m': { interval: '15m', range: '5d' },
  '30m': { interval: '30m', range: '1mo' },
  '1h': { interval: '60m', range: '1mo' },
  '4h': { interval: '60m', range: '3mo', agg: 4 },
};

function aggregate(candles, hours) {
  const size = hours * 3600;
  const map = new Map();
  for (const c of candles) {
    const k = Math.floor(c.time / size) * size;
    const g = map.get(k);
    if (!g) map.set(k, { time: k, open: c.open, high: c.high, low: c.low, close: c.close, volume: c.volume });
    else {
      g.high = Math.max(g.high, c.high);
      g.low = Math.min(g.low, c.low);
      g.close = c.close;
      g.volume += c.volume;
    }
  }
  return [...map.values()].sort((a, b) => a.time - b.time);
}

async function fromYahoo(sym, tf) {
  const cfg = YAHOO[tf];
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(sym)}?interval=${cfg.interval}&range=${cfg.range}&includePrePost=false`;
  const res = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0' }, cache: 'no-store' });
  if (!res.ok) throw new Error(`Yahoo ${res.status}`);
  const j = await res.json();
  const r = j?.chart?.result?.[0];
  if (!r) throw new Error('ডাটা পাওয়া যায়নি');
  const q = r.indicators.quote[0];
  let out = [];
  r.timestamp.forEach((t, i) => {
    if (q.open[i] == null || q.close[i] == null) return;
    out.push({ time: t, open: q.open[i], high: q.high[i], low: q.low[i], close: q.close[i], volume: q.volume?.[i] || 0 });
  });
  if (cfg.agg) out = aggregate(out, cfg.agg);
  return out.slice(-300);
}

async function fromBinance(sym, tf) {
  const hosts = ['https://data-api.binance.vision', 'https://api.binance.com'];
  let lastErr;
  for (const host of hosts) {
    try {
      const res = await fetch(`${host}/api/v3/klines?symbol=${sym}&interval=${tf}&limit=300`, { cache: 'no-store' });
      if (!res.ok) throw new Error(`Binance ${res.status}`);
      const j = await res.json();
      return j.map((k) => ({
        time: Math.floor(k[0] / 1000), open: +k[1], high: +k[2], low: +k[3], close: +k[4], volume: +k[5],
      }));
    } catch (e) { lastErr = e; }
  }
  throw lastErr;
}

export async function GET(req) {
  const { searchParams } = new URL(req.url);
  const id = searchParams.get('id');
  const tf = searchParams.get('tf') || '5m';
  const m = findMarket(id);
  if (!m || !YAHOO[tf]) return NextResponse.json({ error: 'অবৈধ মার্কেট বা টাইমফ্রেম' }, { status: 400 });
  try {
    const candles = m.src === 'binance' ? await fromBinance(m.sym, tf) : await fromYahoo(m.sym, tf);
    return NextResponse.json({ id, tf, candles, fetchedAt: Date.now() });
  } catch (e) {
    return NextResponse.json({ error: e.message }, { status: 502 });
  }
}
