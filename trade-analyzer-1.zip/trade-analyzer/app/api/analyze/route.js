import { NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';
export const maxDuration = 60;

const PROMPT = (ctx) => `তুমি একজন অভিজ্ঞ টেকনিক্যাল অ্যানালিস্ট। সংযুক্ত স্ক্রিনশটটি একটি ট্রেডিং চার্ট। বাংলায় বিস্তারিত রিপোর্ট দাও।

ব্যবহারকারীর দেওয়া তথ্য: ${ctx || 'নেই'}

রিপোর্টের কাঠামো (প্রতিটি শিরোনাম রাখো):
1. মার্কেট/অ্যাসেট ও টাইমফ্রেম (স্ক্রিনশট থেকে যা দেখা যায়)
2. বর্তমান ট্রেন্ড ও মার্কেট স্ট্রাকচার (আপ/ডাউন/রেঞ্জ)
3. ক্যান্ডেল প্যাটার্ন (শেষ কয়েকটি ক্যান্ডেলের বিশ্লেষণ)
4. গুরুত্বপূর্ণ সাপোর্ট ও রেজিস্ট্যান্স লেভেল (চার্টে দেখা দামসহ)
5. ইন্ডিকেটর যা দৃশ্যমান (RSI, MACD, MA, Bollinger ইত্যাদি) ও তার ইঙ্গিত
6. পরবর্তী সম্ভাব্য মুভ: 1 মিনিট, 5 মিনিট, 15 মিনিট, 30 মিনিট, 1 ঘণ্টা, 4 ঘণ্টা — প্রতিটির জন্য দিক (আপ/ডাউন/সাইডওয়েজ) ও সম্ভাব্য টার্গেট
7. ট্রেড প্ল্যান: কোন টাইমফ্রেমের ক্যান্ডেল দেখে এন্ট্রি নেবেন, কনফার্মেশনের জন্য কোন টাইমফ্রেম দেখবেন, কত সময়ের জন্য ট্রেড ধরে রাখবেন (এক্সপায়ারি), এন্ট্রি জোন, স্টপ লস ও টেক প্রফিট
8. ঝুঁকির মাত্রা ও কখন ট্রেড এড়িয়ে যাবেন (যেমন নিউজ, দুর্বল সিগন্যাল)
9. আত্মবিশ্বাসের স্তর (নিম্ন/মাঝারি/উচ্চ) ও কেন

কঠোর নিয়ম:
- স্ক্রিনশটে যা স্পষ্ট দেখা যায় না তা অনুমান করে সংখ্যা বানাবে না; অস্পষ্ট হলে সেটা বলো।
- কোনো ট্রেডকে "নিশ্চিত" বা "100% সফল" বলবে না। কোনো বিশ্লেষণই লাভের গ্যারান্টি দিতে পারে না — এটা শেষে এক লাইনে মনে করিয়ে দাও।
- ছোট ও স্পষ্ট বাক্যে লেখো।`;

export async function POST(req) {
  const gwKey = process.env.AI_GATEWAY_API_KEY;
  const key = process.env.ANTHROPIC_API_KEY;
  if (!gwKey && !key) {
    return NextResponse.json(
      { error: 'AI_GATEWAY_API_KEY (অথবা ANTHROPIC_API_KEY) সেট করা নেই। হোস্টিং সেটিংসে Environment Variable হিসেবে যোগ করুন।' },
      { status: 500 }
    );
  }
  let body;
  try { body = await req.json(); } catch { return NextResponse.json({ error: 'অবৈধ অনুরোধ' }, { status: 400 }); }
  const { image, context } = body || {};
  const m = /^data:(image\/(?:png|jpeg|webp|gif));base64,(.+)$/.exec(image || '');
  if (!m) return NextResponse.json({ error: 'ছবি পাওয়া যায়নি বা ফরম্যাট সমর্থিত নয়' }, { status: 400 });

  try {
    if (gwKey) {
      // Vercel AI Gateway (OpenAI-compatible endpoint)
      const gr = await fetch('https://ai-gateway.vercel.sh/v1/chat/completions', {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: `Bearer ${gwKey}` },
        body: JSON.stringify({
          model: process.env.AI_GATEWAY_MODEL || 'anthropic/claude-sonnet-4.5',
          max_tokens: 2000,
          messages: [{
            role: 'user',
            content: [
              { type: 'text', text: PROMPT(context) },
              { type: 'image_url', image_url: { url: image } },
            ],
          }],
        }),
      });
      const gj = await gr.json();
      if (!gr.ok) return NextResponse.json({ error: gj?.error?.message || `Gateway ত্রুটি ${gr.status}` }, { status: 502 });
      return NextResponse.json({ report: gj.choices?.[0]?.message?.content || '' });
    }
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': key,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5',
        max_tokens: 2000,
        messages: [{
          role: 'user',
          content: [
            { type: 'image', source: { type: 'base64', media_type: m[1], data: m[2] } },
            { type: 'text', text: PROMPT(context) },
          ],
        }],
      }),
    });
    const j = await res.json();
    if (!res.ok) return NextResponse.json({ error: j?.error?.message || `API ত্রুটি ${res.status}` }, { status: 502 });
    const text = (j.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('\n');
    return NextResponse.json({ report: text });
  } catch (e) {
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}
