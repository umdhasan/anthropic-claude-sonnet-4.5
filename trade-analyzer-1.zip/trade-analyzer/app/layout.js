import './globals.css';

export const metadata = {
  title: 'Trade Analyzer',
  description: 'লাইভ মার্কেট ডাটা, মাল্টি-টাইমফ্রেম সিগন্যাল ও স্ক্রিনশট বিশ্লেষণ',
};

export const viewport = { width: 'device-width', initialScale: 1 };

export default function RootLayout({ children }) {
  return (
    <html lang="bn">
      <body>{children}</body>
    </html>
  );
}
