'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import { MARKETS, GROUPS, TFS } from '../lib/markets';
import { analyze, consensus, fmt, TF_PLAN, SIGNAL_BN } from '../lib/analysis';
import { ema } from '../lib/indicators';

async function getCandles(id, tf) {
  const r = await fetch(`/api/candles?id=${id}&tf=${tf}`, { cache: 'no-store' });
  const j = await r.json();
  if (!r.ok) throw new Error(j.error || 'ডাটা আনতে ব্যর্থ');
  return j.candles;
}

function beep() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const o = ctx.createOscillator();
    o.connect(ctx.destination);
    o.frequency.value = 880;
    o.start();
    setTimeout(() => { o.stop(); ctx.close(); }, 250);
  } catch {}
}

function Chart({ candles }) {
  const el = useRef(null);
  const ref = useRef({});

  useEffect(() => {
    let disposed = false;
    let ro;
    (async () => {
      const lw = await import('lightweight-charts');
      if (disposed || !el.current) return;
      const chart = lw.createChart(el.current, {
        height: 380,
        layout: { background: { color: '#131a26' }, textColor: '#8b97ad' },
        grid: { vertLines: { color: '#1b2536' }, horzLines: { color: '#1b2536' } },
        timeScale: { timeVisible: true, secondsVisible: false, borderColor: '#243048' },
        rightPriceScale: { borderColor: '#243048' },
      });
      const candle = chart.addCandlestickSeries({
        upColor: '#22c55e', downColor: '#ef4444', borderVisible: false,
        wickUpColor: '#22c55e', wickDownColor: '#ef4444',
      });
      const l9 = chart.addLineSeries({ color: '#60a5fa', lineWidth: 1, priceLineVisible: false });
      const l21 = chart.addLineSeries({ color: '#f59e0b', lineWidth: 1, priceLineVisible: false });
      ref.current = { chart, candle, l9, l21 };
      ro = new ResizeObserver(() => chart.applyOptions({ width: el.current.clientWidth }));
      ro.observe(el.current);
      ref.current.ready?.();
    })();
    return () => { disposed = true; ro?.disconnect(); ref.current.chart?.remove(); ref.current = {}; };
  }, []);

  useEffect(() => {
    const apply = () => {
      const { candle, l9, l21 } = ref.current;
      if (!candle || !candles?.length) return;
      candle.setData(candles);
      const c = candles.map((x) => x.close);
      const mk = (arr) => arr.map((v, i) => (v == null ? null : { time: candles[i].time, value: v })).filter(Boolean);
      l9.setData(mk(ema(c, 9)));
      l21.setData(mk(ema(c, 21)));
    };
    if (ref.current.candle) apply(); else ref.current.ready = apply;
  }, [candles]);

  return <div ref={el} className="chart" />;
}

function SignalBadge({ s }) {
  return <span className={`sig ${s}`}>{SIGNAL_BN[s]}</span>;
}

function Screenshot({ market, tf, a }) {
  const [img, setImg] = useState(null);
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [report, setReport] = useState('');
  const [err, setErr] = useState('');

  const load = (file) => {
    if (!file || !file.type.startsWith('image/')) return;
    const fr = new FileReader();
    fr.onload = () => {
      const im = new Image();
      im.onload = () => {
        const max = 1600;
        const k = Math.min(1, max / Math.max(im.width, im.height));
        const cv = document.createElement('canvas');
        cv.width = Math.round(im.width * k);
        cv.height = Math.round(im.height * k);
        cv.getContext('2d').drawImage(im, 0, 0, cv.width, cv.height);
        setImg(cv.toDataURL('image/jpeg', 0.85));
        setReport(''); setErr('');
      };
      im.src = fr.result;
    };
    fr.readAsDataURL(file);
  };

  useEffect(() => {
    const onPaste = (e) => {
      const f = [...(e.clipboardData?.files || [])][0];
      if (f) load(f);
    };
    window.addEventListener('paste', onPaste);
    return () => window.removeEventListener('paste', onPaste);
  }, []);

  const run = async () => {
    setBusy(true); setErr(''); setReport('');
    const live = a
      ? `লাইভ ডাটা (${market.label}, ${tf}): দাম ${fmt(a.price)}, সিগন্যাল ${a.signal}, RSI ${a.ind.rsi.toFixed(0)}, সাপোর্ট ${fmt(a.support)}, রেজিস্ট্যান্স ${fmt(a.resistance)}`
      : '';
    try {
      const r = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ image: img, context: `${market.label} ${tf}। ${note} ${live}` }),
      });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error);
      setReport(j.report);
    } catch (e) { setErr(e.message); }
    setBusy(false);
  };

  return (
    <div className="card">
      <b>স্ক্রিনশট বিশ্লেষণ</b>
      <p className="muted">যেকোনো প্ল্যাটফর্মের (Pocket Option, Quotex, MT5 ইত্যাদি) চার্টের স্ক্রিনশট দিন। Ctrl+V দিয়ে পেস্টও করা যায়।</p>
      <div className="drop">
        <input type="file" accept="image/*" onChange={(e) => load(e.target.files?.[0])} />
        {img && <img className="preview" src={img} alt="screenshot" />}
      </div>
      <input
        style={{ width: '100%', marginTop: 8, background: '#0b0f17', color: '#e6ebf5', border: '1px solid #243048', borderRadius: 8, padding: 8 }}
        placeholder="ঐচ্ছিক নোট: যেমন 'এখন 5 মিনিটের ট্রেড নেব'"
        value={note} onChange={(e) => setNote(e.target.value)}
      />
      <div style={{ marginTop: 8 }}>
        <button className="on" disabled={!img || busy} onClick={run}>{busy ? 'বিশ্লেষণ চলছে…' : 'রিপোর্ট তৈরি করুন'}</button>
      </div>
      {err && <p style={{ color: '#ef4444' }}>{err}</p>}
      {report && <div className="report card" style={{ marginTop: 10 }}>{report}</div>}
    </div>
  );
}

export default function Home() {
  const [marketId, setMarketId] = useState('EURUSD');
  const [tf, setTf] = useState('5m');
  const [candles, setCandles] = useState([]);
  const [mtf, setMtf] = useState({});
  const [err, setErr] = useState('');
  const [updated, setUpdated] = useState(null);
  const [tab, setTab] = useState('live');
  const [notif, setNotif] = useState(false);
  const prev = useRef({});
  const notifRef = useRef(false);
  notifRef.current = notif;

  const market = MARKETS.find((m) => m.id === marketId);
  const a = analyze(candles);

  const loadMain = useCallback(async () => {
    try { setCandles(await getCandles(marketId, tf)); setErr(''); setUpdated(new Date()); }
    catch (e) { setErr(e.message); }
  }, [marketId, tf]);

  const loadMtf = useCallback(async () => {
    const res = await Promise.all(TFS.map(async (t) => {
      try { return [t, analyze(await getCandles(marketId, t))]; } catch { return [t, null]; }
    }));
    const map = Object.fromEntries(res);
    setMtf(map);
    // অ্যালার্ট
    for (const [t, x] of res) {
      if (!x) continue;
      const old = prev.current[`${marketId}-${t}`];
      const key = x.sharpDrop ? 'DROP' : x.sharpRise ? 'RISE' : x.signal;
      if (old && old !== key && notifRef.current && ['1m', '5m', '15m'].includes(t)) {
        const msg =
          key === 'DROP' ? `${marketId} ${t}: দ্রুত ডাউন! মার্কেট এখন নিচে নামছে`
          : key === 'RISE' ? `${marketId} ${t}: দ্রুত আপ! মার্কেট বাড়ছে`
          : `${marketId} ${t}: সিগন্যাল বদলে ${SIGNAL_BN[key]}`;
        beep();
        if ('Notification' in window && Notification.permission === 'granted') new Notification('Trade Analyzer', { body: msg });
      }
      prev.current[`${marketId}-${t}`] = key;
    }
  }, [marketId]);

  useEffect(() => { loadMain(); const i = setInterval(loadMain, 15000); return () => clearInterval(i); }, [loadMain]);
  useEffect(() => { setMtf({}); loadMtf(); const i = setInterval(loadMtf, 60000); return () => clearInterval(i); }, [loadMtf]);

  const toggleNotif = async () => {
    if (!notif && 'Notification' in window && Notification.permission !== 'granted') await Notification.requestPermission();
    setNotif(!notif);
  };

  const cons = consensus(mtf);
  const plan = TF_PLAN[tf];

  return (
    <div className="wrap">
      <h1>📈 Trade Analyzer — লাইভ ডাটা ও সিগন্যাল</h1>

      <div className="tabs">
        <button className={tab === 'live' ? 'on' : ''} onClick={() => setTab('live')}>লাইভ চার্ট</button>
        <button className={tab === 'shot' ? 'on' : ''} onClick={() => setTab('shot')}>স্ক্রিনশট বিশ্লেষণ</button>
        <button className={notif ? 'on' : ''} onClick={toggleNotif}>{notif ? '🔔 অ্যালার্ট চালু' : '🔕 অ্যালার্ট বন্ধ'}</button>
      </div>

      <div className="bar">
        <select value={marketId} onChange={(e) => setMarketId(e.target.value)}>
          {GROUPS.map((g) => (
            <optgroup key={g} label={g}>
              {MARKETS.filter((m) => m.group === g).map((m) => <option key={m.id} value={m.id}>{m.label}</option>)}
            </optgroup>
          ))}
        </select>
        <div className="tfs">
          {TFS.map((t) => <button key={t} className={`tf ${t === tf ? 'on' : ''}`} onClick={() => setTf(t)}>{t}</button>)}
        </div>
      </div>

      {tab === 'shot' ? <Screenshot market={market} tf={tf} a={a} /> : (
        <div className="grid">
          <div>
            <div className="card">
              <Chart candles={candles} />
              <p className="muted">
                নীল = EMA9, কমলা = EMA21 • {updated ? `আপডেট: ${updated.toLocaleTimeString('bn-BD')}` : 'লোড হচ্ছে…'} • প্রতি 15 সেকেন্ডে রিফ্রেশ
              </p>
              {err && <p style={{ color: '#ef4444' }}>{err} (মার্কেট বন্ধ থাকলে ফরেক্স/স্টক ডাটা আসে না)</p>}
            </div>

            <div className="card">
              <b>সব টাইমফ্রেমে পরবর্তী সম্ভাব্য দিক</b>
              <table>
                <thead><tr><th>TF</th><th>সিগন্যাল</th><th>শক্তি</th><th>RSI</th><th>সম্ভাব্য টার্গেট</th></tr></thead>
                <tbody>
                  {TFS.map((t) => {
                    const x = mtf[t];
                    return (
                      <tr key={t}>
                        <td>{t}</td>
                        <td>{x ? <SignalBadge s={x.signal} /> : '…'}</td>
                        <td>{x ? `${x.strength}%` : ''}</td>
                        <td>{x ? x.ind.rsi.toFixed(0) : ''}</td>
                        <td>{x ? fmt(x.signal === 'SELL' ? x.targets.tp1 : x.signal === 'BUY' ? x.targets.tp1 : x.price) : ''}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              <p className="muted">সম্মিলিত মত: <SignalBadge s={cons.signal} /> ({cons.pct}% সামঞ্জস্য) • প্রতি মিনিটে আপডেট</p>
            </div>
          </div>

          <div>
            <div className="card">
              <div className="muted">{market.label} • {tf}</div>
              <div className="price">{a ? fmt(a.price) : '…'}</div>
              {a && (
                <>
                  <SignalBadge s={a.signal} />
                  <div className="bar-meter"><i style={{ width: `${a.strength}%`, background: a.signal === 'SELL' ? '#ef4444' : a.signal === 'BUY' ? '#22c55e' : '#eab308' }} /></div>
                  <p className="muted">সিগন্যাল শক্তি {a.strength}% (এটি জয়ের সম্ভাবনা নয়)</p>
                  {(a.sharpDrop || a.sharpRise) && <p style={{ color: a.sharpDrop ? '#ef4444' : '#22c55e' }}>{a.sharpDrop ? '⚠ মার্কেট দ্রুত নামছে' : '⚠ মার্কেট দ্রুত উঠছে'}</p>}
                  <table>
                    <tbody>
                      <tr><td>সাপোর্ট</td><td>{fmt(a.support)}</td></tr>
                      <tr><td>রেজিস্ট্যান্স</td><td>{fmt(a.resistance)}</td></tr>
                      <tr><td>পরবর্তী ক্যান্ডেল রেঞ্জ</td><td>{fmt(a.targets.nextLow)} – {fmt(a.targets.nextHigh)}</td></tr>
                      {a.signal !== 'NEUTRAL' && (<>
                        <tr><td>TP1 / TP2</td><td>{fmt(a.targets.tp1)} / {fmt(a.targets.tp2)}</td></tr>
                        <tr><td>স্টপ লস</td><td>{fmt(a.targets.sl)}</td></tr>
                      </>)}
                    </tbody>
                  </table>
                </>
              )}
            </div>

            <div className="card">
              <b>ট্রেড প্ল্যান ({tf})</b>
              <ul>
                <li>এন্ট্রি দেখুন: {plan.entry}</li>
                <li>কনফার্মেশন: {plan.confirm} টাইমফ্রেম একই দিকে কি না</li>
                <li>ট্রেডের সময়: {plan.hold}</li>
                <li>এন্ট্রি শুধু তখনই, যখন {tf} ও কনফার্ম টাইমফ্রেমের সিগন্যাল মিলে যায়</li>
              </ul>
            </div>

            <div className="card">
              <b>কেন এই সিগন্যাল</b>
              <ul>{a?.reasons.map((r, i) => <li key={i}>{r}</li>)}</ul>
            </div>
          </div>
        </div>
      )}

      <div className="warn">
        ⚠ এই অ্যাপ ইন্ডিকেটর-ভিত্তিক শিক্ষামূলক বিশ্লেষণ দেয়। কোনো সিস্টেমই 100% সফলতার নিশ্চয়তা দিতে পারে না — ট্রেডিংয়ে পুরো মূলধন হারানোর ঝুঁকি আছে। ডেমো অ্যাকাউন্টে আগে পরীক্ষা করুন এবং ছোট ঝুঁকি নিন।
        ডাটা Yahoo Finance ও Binance পাবলিক সোর্স থেকে আসে (কিছু ক্ষেত্রে সামান্য বিলম্ব থাকতে পারে) এবং আপনার ব্রোকারের প্রাইসের সাথে হুবহু না-ও মিলতে পারে।
      </div>
    </div>
  );
}
